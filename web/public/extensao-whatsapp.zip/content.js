// Content script do web.whatsapp.com.
//  - injeta a wa-js + wa-inject.js no contexto da página
//  - mostra um cartão flutuante ("Amor In") com a turma vinculada à conversa aberta
//    e um seletor pra vincular/trocar (DM pelo telefone, grupo pelo nome)
//  - orquestra a varredura: manda as mensagens novas da conversa vinculada.
(function () {
  'use strict';
  const CFG = window.AMORIN_CONFIG;
  const TAG = '[AmorIn]';
  const log = (...a) => console.log(TAG, ...a);

  // ---- injeta scripts no contexto da página ----
  function injetar(arquivo) {
    return new Promise((resolve) => {
      const s = document.createElement('script');
      s.src = chrome.runtime.getURL(arquivo);
      s.onload = () => { s.remove(); resolve(); };
      (document.head || document.documentElement).appendChild(s);
    });
  }

  // ---- ponte com a página ----
  const pendentes = new Map();
  let seq = 0;
  window.addEventListener('message', (ev) => {
    if (ev.source !== window || !ev.data) return;
    if (ev.data.__amorin === 'res') {
      const p = pendentes.get(ev.data.reqId);
      if (p) {
        pendentes.delete(ev.data.reqId);
        ev.data.erro ? p.reject(new Error(ev.data.erro)) : p.resolve(ev.data.payload);
      }
    }
    if (ev.data.__amorin === 'evt' && ev.data.evt === 'chat_mudou') {
      clearTimeout(window.__amorinDebounce);
      window.__amorinDebounce = setTimeout(() => { atualizarChat(); }, 1200);
    }
    if (ev.data.__amorin === 'evt' && ev.data.evt === 'pronto') paginaPronta = true;
  });
  let paginaPronta = false;
  function pedir(req, params) {
    return new Promise((resolve, reject) => {
      const reqId = `${Date.now()}-${seq++}`;
      pendentes.set(reqId, { resolve, reject });
      window.postMessage({ __amorin: 'req', reqId, req, params }, '*');
      setTimeout(() => {
        if (pendentes.has(reqId)) { pendentes.delete(reqId); reject(new Error('timeout ' + req)); }
      }, 60000);
    });
  }
  const bg = (cmd, dados) =>
    new Promise((resolve) => chrome.runtime.sendMessage({ cmd, ...dados }, resolve));

  // ---- estado local ----
  async function getEstado() {
    const { amorin_estado } = await chrome.storage.local.get('amorin_estado');
    return amorin_estado || { sincronizadoAte: {}, salvasHoje: 0, dia: '', ultimaSync: null };
  }
  async function setEstado(e) { await chrome.storage.local.set({ amorin_estado: e }); }

  // ---- cache de turmas ----
  let turmasCache = null;
  async function getTurmas() {
    if (turmasCache) return turmasCache;
    const r = await bg('wa_turmas');
    turmasCache = (r && r.turmas) || [];
    return turmasCache;
  }

  // ---- cache de mensagens padrão ----
  let mensagensPadraoCache = null;
  async function getMensagensPadrao() {
    if (mensagensPadraoCache) return mensagensPadraoCache;
    const r = await bg('wa_mensagens_padrao');
    mensagensPadraoCache = (r && r.mensagens) || [];
    return mensagensPadraoCache;
  }

  // =========================================================================
  //  PAINEL  (sidebar completa, estilo Moskit, dentro do próprio WhatsApp Web)
  // =========================================================================
  const host = document.createElement('div');
  host.id = 'amorin-wa-widget';
  const root = host.attachShadow({ mode: 'open' });
  root.innerHTML = `
    <style>
      :host{
        --bg1:#0c0f13; --bg2:#0a0c10; --panel-border:rgba(255,255,255,.07); --hair:rgba(255,255,255,.055);
        --text:#f4f2ee; --dim:#95a0ad; --accent:#f97316; --accent-soft:rgba(249,115,22,.12);
        --z:2147483000;
      }
      *{box-sizing:border-box;font-family:-apple-system,"Segoe UI",Roboto,sans-serif;line-height:1.5}
      *::-webkit-scrollbar{width:5px;height:5px}
      *::-webkit-scrollbar-track{background:transparent}
      *::-webkit-scrollbar-thumb{background:rgba(255,255,255,.14);border-radius:99px}
      *::-webkit-scrollbar-thumb:hover{background:rgba(255,255,255,.22)}
      .aba{position:fixed;top:45%;right:0;transform:translateY(-50%);writing-mode:vertical-rl;text-orientation:mixed;
        background:linear-gradient(180deg,#15191f,#0d1014);color:#e7e2da;padding:16px 7px;border-radius:12px 0 0 12px;
        font-size:11px;font-weight:500;letter-spacing:1.5px;cursor:pointer;
        border:1px solid var(--panel-border);border-right:none;box-shadow:-6px 0 24px rgba(0,0,0,.28);
        transition:padding .15s ease,box-shadow .15s ease;z-index:var(--z)}
      .aba::before{content:'';position:absolute;top:10px;left:6px;right:6px;height:1.5px;background:var(--accent);border-radius:99px;opacity:.85}
      .aba:hover{padding-right:11px;box-shadow:-8px 0 28px rgba(0,0,0,.36)}
      .aba.atras-de-overlay{z-index:1}
      .painel{position:fixed;top:0;right:-360px;width:340px;height:100vh;color:var(--text);
        background:
          radial-gradient(120% 55% at 100% 0%,rgba(249,115,22,.055),transparent 60%),
          linear-gradient(180deg,var(--bg1),var(--bg2));
        border-left:1px solid var(--panel-border);
        box-shadow:-14px 0 48px rgba(0,0,0,.32),inset 1px 0 0 rgba(255,255,255,.02);
        transition:right .24s cubic-bezier(.2,.7,.3,1);display:flex;flex-direction:column;
        z-index:var(--z);font-size:12px}
      .painel.aberto{right:0}
      .painel.atras-de-overlay{z-index:1}
      header{padding:16px 16px 14px;display:flex;align-items:center;gap:8px;font-weight:600;font-size:13px;
        letter-spacing:.2px;flex:none;border-bottom:1px solid var(--hair);
        background:linear-gradient(180deg,rgba(255,255,255,.025),transparent)}
      header .marca{color:var(--text)}
      header .marca b{color:var(--accent);font-weight:600}
      header .x{margin-left:auto;cursor:pointer;font-size:15px;line-height:1;color:var(--dim);width:22px;height:22px;
        border-radius:50%;display:flex;align-items:center;justify-content:center;transition:background .12s,color .12s}
      header .x:hover{background:rgba(255,255,255,.07);color:var(--text)}
      .body{padding:16px;overflow-y:auto;flex:1;display:flex;flex-direction:column;gap:13px}
      .chat{font-weight:600;color:var(--text);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:13px;letter-spacing:.1px}
      .tag{font-size:10px;color:var(--dim)}
      .link{display:flex;align-items:center;gap:7px;padding:9px 11px;border-radius:12px;border:1px solid var(--hair);
        background:rgba(255,255,255,.025)}
      .link.ok{border-color:#34d39940;background:#34d3990d}
      .link.no{border-color:#f59e0b40;background:#f59e0b0d}
      .dot{width:6px;height:6px;border-radius:50%;flex:none}
      .ok .dot{background:#34d399}.no .dot{background:#f59e0b}
      .link span{flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      button{border:0;border-radius:11px;cursor:pointer;font-weight:600;font-size:12px;padding:9px 12px;
        letter-spacing:.15px;transition:filter .12s,opacity .12s,background .12s}
      button:hover{filter:brightness(1.08)}
      button:disabled{opacity:.5;cursor:default;filter:none}
      .b{background:linear-gradient(135deg,#fb923c,#ea580c);color:#fff;width:100%;
        box-shadow:0 6px 16px -6px rgba(249,115,22,.55)}
      .g{background:rgba(255,255,255,.04);color:#e2e8f0;border:1px solid var(--hair);width:100%;font-weight:500}
      .g:hover{background:rgba(255,255,255,.065)}
      .pill{width:100%;border-radius:99px;font-weight:600;padding:10px;border:1px solid;background:transparent}
      .pill-orange{color:#fb923c;border-color:#f9731645;background:#f9731610}
      .pill-red{color:#f87171;border-color:#f8717145;background:#f8717110}
      input,select{width:100%;padding:9px 11px;border-radius:11px;border:1px solid var(--hair);
        background:rgba(255,255,255,.03);color:var(--text);font-family:inherit;font-size:12px;transition:border-color .12s}
      input:focus,select:focus,textarea:focus{outline:none;border-color:#f9731666}
      select{cursor:pointer}
      .lista{max-height:260px;overflow-y:auto;display:flex;flex-direction:column;gap:3px}
      .item{padding:9px 11px;border-radius:10px;cursor:pointer;color:#c7ccd3;white-space:nowrap;overflow:hidden;
        text-overflow:ellipsis;line-height:1.3;transition:background .1s}
      .item:hover{background:rgba(255,255,255,.055);color:#fff}
      .row{display:flex;gap:8px}
      .msgs{max-height:280px;overflow-y:auto;display:flex;flex-direction:column;gap:5px}
      .msg{padding:9px 11px;border-radius:12px;background:rgba(255,255,255,.025);border:1px solid var(--hair)}
      .msg.mim{background:#f9731612;border-color:#f9731628}
      .msg .qm{color:var(--dim);font-size:10px;margin-bottom:2px}
      .msg .tx{color:#e2e8f0;white-space:pre-wrap;word-break:break-word}
      .muted{color:#6b7480;font-size:10px}
      .sec{border-top:1px solid var(--hair);padding-top:13px;display:flex;flex-direction:column;gap:8px}
      .sec .titulo{font-size:9.5px;font-weight:600;color:var(--dim);text-transform:uppercase;letter-spacing:1px}
      .linha2{display:flex;justify-content:space-between;font-size:11px;color:var(--dim);padding:5px 0;
        border-bottom:1px solid var(--hair)}
      .linha2 b{color:var(--text);font-weight:600}
      .linha2.alerta{color:#fbbf24;border-color:#78350f40}
      .prob{display:flex;align-items:center;gap:8px;padding:2px 0}
      .prob .barra{flex:1;height:4px;border-radius:99px;background:rgba(255,255,255,.07);overflow:hidden}
      .prob .barra i{display:block;height:100%;background:linear-gradient(90deg,#f97316,#fb923c);border-radius:99px}
      .prob b{font-size:12px;color:var(--text);min-width:32px;text-align:right;font-weight:600}
      .padrao{display:flex;flex-direction:column;gap:5px;max-height:180px;overflow-y:auto}
      .padrao .item2{padding:9px 11px;border-radius:12px;border:1px solid var(--hair);background:rgba(255,255,255,.025);cursor:pointer;transition:border-color .12s,background .12s}
      .padrao .item2:hover{border-color:#f9731655;background:#f973160a}
      .padrao .item2 .t{font-weight:600;color:var(--text);font-size:11px}
      .padrao .item2 .p{color:#838a93;font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px}
      textarea{width:100%;padding:9px 11px;border-radius:11px;border:1px solid var(--hair);
        background:rgba(255,255,255,.03);color:var(--text);font-family:inherit;font-size:12px;resize:vertical}
      .stageCard{border:1px solid var(--hair);border-radius:12px;padding:9px 11px;margin-bottom:6px;
        background:rgba(255,255,255,.015)}
      .stageCard.atual{border-color:#f9731650;background:#f973160c}
      .stageTop{display:flex;align-items:center;gap:6px;font-size:11px;color:var(--text);font-weight:600;margin-bottom:4px}
      .stageTop .badge{background:transparent;border:1px solid var(--accent);color:#fb923c;font-size:9px;font-weight:700;
        padding:2px 7px;border-radius:99px;letter-spacing:.4px}
      .stageTop .contagem{margin-left:auto;color:var(--dim);font-weight:600;font-size:10px}
      .itemCk{display:flex;gap:6px;align-items:flex-start;padding:3px 0;cursor:pointer;font-size:11px;color:#cbd5e1}
      .itemCk input{width:auto;margin-top:2px;flex:none}
      .itemCk span{flex:1}
      summary{outline:none}
      [hidden]{display:none!important}
    </style>
    <div class="aba" id="aba">🪶&nbsp;&nbsp;Amor In</div>
    <div class="painel aberto" id="painel">
      <header><span class="marca">🪶 <b>Amor In</b></span><span class="x" id="fechar">&times;</span></header>
      <div class="body" id="body"><span class="muted">Abrindo…</span></div>
    </div>
  `;
  const $ = (id) => root.getElementById(id);
  const painelEl = $('painel');
  const abaEl = $('aba');

  // O próprio WhatsApp Web também abre coisas (menu de "Editar" mensagem,
  // seletor de emoji, modal de encaminhar...) como filho direto de <body>,
  // igual o nosso host. Como o painel usava z-index praticamente infinito,
  // ele sempre ficava por cima e escondia esses menus atrás. Detecta quando
  // algo assim aparece e recua o painel enquanto durar.
  const overlaysExternos = new Set();
  const overlayObserver = new MutationObserver((mutations) => {
    for (const m of mutations) {
      for (const n of m.addedNodes) {
        if (n.nodeType !== 1 || n === host || n.id === 'app') continue;
        const r = n.getBoundingClientRect();
        if (r.width >= 4 && r.height >= 4) overlaysExternos.add(n);
      }
      for (const n of m.removedNodes) overlaysExternos.delete(n);
    }
    const atras = overlaysExternos.size > 0;
    painelEl.classList.toggle('atras-de-overlay', atras);
    abaEl.classList.toggle('atras-de-overlay', atras);
  });
  overlayObserver.observe(document.body, { childList: true });

  // Empurra o WhatsApp Web (não só cobre por cima) — o app deles usa
  // #app { position:absolute; inset:0; width:100% } (testado de verdade no
  // web.whatsapp.com). Só mudar `right` não basta: como width também tá
  // explícito, a caixa fica "over-constrained" e o CSS ignora o `right` —
  // precisa sobrescrever width também (calc(100% - Npx)).
  const LARGURA_PAINEL = 340;
  const estiloEmpurrar = document.createElement('style');
  estiloEmpurrar.textContent = `
    #app { transition: right .22s ease, width .22s ease; }
    html.amorin-painel-aberto #app { right: ${LARGURA_PAINEL}px !important; width: calc(100% - ${LARGURA_PAINEL}px) !important; }
  `;
  (document.head || document.documentElement).appendChild(estiloEmpurrar);

  function abrirPainel() {
    painelEl.classList.add('aberto');
    document.documentElement.classList.add('amorin-painel-aberto');
    render();
  }
  function fecharPainel() {
    painelEl.classList.remove('aberto');
    document.documentElement.classList.remove('amorin-painel-aberto');
  }
  $('aba').onclick = abrirPainel;
  $('fechar').onclick = fecharPainel;

  let chatAtual = null;   // { id, isGroup, nome, telefone }
  let vinculoAtual = null; // resposta do resolver
  let infoChat = null;     // resposta do chat_info (arquivadas, última)
  let metricas = null;     // resposta do turma_metricas (status, dias na fase, próxima reunião...)
  let modoSeletor = false;
  let modoSeletorAcao = 'vincular'; // 'vincular' | 'contato'
  let modoConversa = false;
  let mensagensConversa = null;
  let filtro = '';

  function formatarQuando(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    const dd = String(d.getDate()).padStart(2, '0');
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const hh = String(d.getHours()).padStart(2, '0');
    const mi = String(d.getMinutes()).padStart(2, '0');
    return `${dd}/${mm} ${hh}:${mi}`;
  }

  function render() {
    // Enquanto o vendedor está digitando/preenchendo algum campo (observações,
    // agendar reunião...), não reconstrói o painel embaixo do dedo — senão
    // perde o texto e o foco (mesma classe de bug do campo de busca de turma,
    // corrigida antes).
    // document.activeElement não vê dentro de shadow DOM aberto (retorna o
    // host) — precisa perguntar pro próprio shadow root quem tá focado nele.
    const ae = root.activeElement;
    if (ae && ae.tagName === 'TEXTAREA') return;
    if (ae && ae.tagName === 'INPUT' && ae.type !== 'checkbox') return;
    const b = $('body');
    if (!chatAtual) {
      b.innerHTML = `<span class="muted">Abra uma conversa pra vincular a uma turma.</span>`;
      return;
    }
    const nome = (chatAtual.nome || 'Conversa').replace(/</g, '&lt;');
    const tipo = chatAtual.isGroup ? 'Grupo' : 'Pessoa';
    const via = chatAtual.isGroup ? 'pelo nome do grupo' : 'pelo telefone';

    if (modoConversa) {
      const lista = mensagensConversa === null
        ? '<span class="muted">Carregando…</span>'
        : (mensagensConversa.length
          ? mensagensConversa.map((m) => `
              <div class="msg ${m.de_mim ? 'mim' : ''}">
                <div class="qm">${m.de_mim ? 'Eu' : (m.autor_nome || 'Contato').replace(/</g, '&lt;')} · ${formatarQuando(m.enviada_em)}${m.transcrito ? ' · 🎤 áudio' : ''}</div>
                <div class="tx">${(m.texto || '(sem texto)').replace(/</g, '&lt;')}</div>
              </div>
            `).join('')
          : '<span class="muted">Nada arquivado ainda.</span>');
      b.innerHTML = `
        <div class="chat">${nome}</div>
        <div class="tag">Conversa arquivada</div>
        <div class="msgs" id="msgs">${lista}</div>
        <button class="g" id="voltar" style="width:100%">Voltar</button>
      `;
      $('voltar').onclick = () => { modoConversa = false; render(); };
      return;
    }

    if (modoSeletor) {
      const legenda = modoSeletorAcao === 'contato'
        ? 'Criar contato pra essa pessoa e escolher a turma'
        : `${tipo} · vínculo ${via}`;
      b.innerHTML = `
        <div class="chat">${nome}</div>
        <div class="tag">${legenda}</div>
        <input id="busca" placeholder="Buscar turma…" value="${filtro.replace(/"/g, '&quot;')}" />
        <div class="lista" id="lista"></div>
        <div class="row">
          <button class="g" id="cancelar" style="flex:1">Cancelar</button>
          ${modoSeletorAcao === 'vincular' ? '<button class="g" id="naoturma" style="flex:1">Não é de turma</button>' : ''}
        </div>
      `;
      // A lista é re-renderizada a cada letra digitada, mas o <input> em si
      // nunca é recriado — senão perde o foco a cada tecla (só aceitava uma
      // letra por vez porque o re-render trocava o elemento debaixo do dedo).
      const renderLista = () => {
        const turmas = (turmasCache || []).filter((t) =>
          !filtro || t.nome.toLowerCase().includes(filtro.toLowerCase()),
        );
        $('lista').innerHTML =
          turmas.slice(0, 60).map((t) => `<div class="item" data-id="${t.id}">${t.nome.replace(/</g, '&lt;')}</div>`).join('') ||
          '<span class="muted">Nenhuma turma.</span>';
        $('lista').querySelectorAll('.item').forEach((el) => {
          el.onclick = () => (modoSeletorAcao === 'contato' ? criarContato(el.getAttribute('data-id')) : vincular(el.getAttribute('data-id')));
        });
      };
      renderLista();
      const busca = $('busca');
      busca.oninput = () => { filtro = busca.value; renderLista(); };
      busca.focus();
      busca.setSelectionRange(filtro.length, filtro.length);
      $('cancelar').onclick = () => { modoSeletor = false; render(); };
      if ($('naoturma')) $('naoturma').onclick = () => vincular(null, true);
      return;
    }

    const v = vinculoAtual;
    const temTurma = v && v.turma_id && !v.vincular;
    const nomeTurma = temTurma ? (turmaNomePorId(v.turma_id) || 'turma vinculada') : null;
    const temContato = !!(v && v.contato_id);
    const semContatoAindaDM = !chatAtual.isGroup && !temContato;
    const infoLinha = infoChat && infoChat.arquivadas > 0
      ? `<div class="tag">${infoChat.arquivadas} mensagem${infoChat.arquivadas === 1 ? '' : 's'} arquivada${infoChat.arquivadas === 1 ? '' : 's'}${infoChat.ultima ? ' · última ' + formatarQuando(infoChat.ultima) : ''}</div>`
      : '';
    const sincronizandoAgora = sincronizandoChatId === chatAtual.id;
    b.innerHTML = `
      <div class="chat">${nome}</div>
      <div class="tag">${tipo} · vínculo ${via}</div>
      <div class="link ${temTurma ? 'ok' : 'no'}">
        <span class="dot"></span>
        <span>${temTurma ? nomeTurma.replace(/</g, '&lt;') : (v && v.ignorar ? 'Marcada como "não é de turma"' : 'Não vinculada')}</span>
      </div>
      ${sincronizandoAgora ? '<div class="tag">🔄 Sincronizando mensagens…</div>' : ''}
      ${infoLinha}
      <button class="b" id="vincular">${temTurma ? 'Trocar turma' : 'Vincular a uma turma'}</button>
      ${semContatoAindaDM ? '<button class="g" id="criarcontato" style="width:100%">Criar contato + vincular</button>' : ''}
      ${infoChat && infoChat.arquivadas > 0 ? '<button class="g" id="verconversa" style="width:100%">Ver conversa arquivada</button>' : ''}
      ${temTurma ? '' : '<span class="muted">Enquanto não vincular, nada dessa conversa é salvo.</span>'}
      ${temTurma ? `
      <div class="sec">
        <div class="titulo">Turma no funil</div>
        ${metricasSecaoHtml(v.turma_id)}
      </div>
      <div class="sec">
        <div class="titulo">Informações da turma</div>
        ${infoTurmaSecaoHtml(v.turma_id)}
      </div>
      <div class="sec">
        <div class="titulo">Contatos</div>
        ${pessoasSecaoHtml(v.turma_id)}
      </div>
      <div class="sec">
        <div class="titulo">Pacotes da turma</div>
        ${pacotesSecaoHtml(v.turma_id)}
      </div>
      <div class="sec">
        <div class="titulo">Etapa e checklist</div>
        ${etapaSecaoHtml(v.turma_id)}
      </div>
      <div class="sec">
        <div class="titulo">Agendar reunião</div>
        ${agendarSecaoHtml()}
      </div>
      <div class="sec">
        <div class="titulo">Observações da turma</div>
        <textarea id="obs" rows="3" placeholder="Escreva aqui — salva direto na turma…"></textarea>
        <button class="g" id="salvarObs" style="width:100%">Salvar observações</button>
      </div>` : ''}
      <div class="sec">
        <div class="titulo">Mensagens padrão</div>
        <div class="padrao" id="padrao"><span class="muted">Carregando…</span></div>
      </div>
    `;
    $('vincular').onclick = async () => { await getTurmas(); modoSeletor = true; modoSeletorAcao = 'vincular'; filtro = ''; render(); };
    if ($('criarcontato')) $('criarcontato').onclick = async () => { await getTurmas(); modoSeletor = true; modoSeletorAcao = 'contato'; filtro = ''; render(); };
    if ($('verconversa')) $('verconversa').onclick = verConversa;
    if ($('salvarObs')) $('salvarObs').onclick = () => salvarObservacoes(v.turma_id);
    if ($('obs') && metricas && metricas.__turmaId === v.turma_id) $('obs').value = metricas.observacoes || '';
    ligarInfoTurmaSecao(v.turma_id);
    ligarPessoasSecao(v.turma_id);
    ligarPacotesSecao(v.turma_id);
    ligarEtapaSecao(v.turma_id);
    ligarAgendarSecao(v.turma_id);
    renderMensagensPadrao();
  }

  async function salvarObservacoes(turmaId) {
    const campo = $('obs');
    const botao = $('salvarObs');
    if (!campo || !botao) return;
    const texto = campo.value;
    botao.textContent = 'Salvando…';
    botao.disabled = true;
    const r = await bg('wa_atualizar_observacoes', { payload: { turma_id: turmaId, observacoes: texto } });
    botao.disabled = false;
    botao.textContent = r && r.ok ? '✓ Salvo' : 'Erro — tentar de novo';
    if (r && r.ok && metricas) metricas.observacoes = texto;
    setTimeout(() => { if ($('salvarObs')) $('salvarObs').textContent = 'Salvar observações'; }, 2000);
  }

  async function renderMensagensPadrao() {
    const idAlvo = chatAtual && chatAtual.id;
    const lista = await getMensagensPadrao();
    const alvo = $('padrao');
    if (!alvo || !chatAtual || chatAtual.id !== idAlvo) return; // conversa trocou enquanto carregava
    if (!lista.length) {
      alvo.innerHTML = '<span class="muted">Nenhuma cadastrada ainda (Admin → WhatsApp Comercial).</span>';
      return;
    }
    alvo.innerHTML = lista.map((m) => `
      <div class="item2" data-id="${m.id}">
        <div class="t">${(m.titulo || '').replace(/</g, '&lt;')}</div>
        <div class="p">${(m.texto || '').replace(/</g, '&lt;')}</div>
      </div>
    `).join('');
    alvo.querySelectorAll('.item2').forEach((el) => {
      el.onclick = () => {
        const m = lista.find((x) => x.id === el.getAttribute('data-id'));
        if (m) enviarMensagemPadrao(m.texto);
      };
    });
  }

  async function enviarMensagemPadrao(texto) {
    if (!chatAtual || !texto) return;
    const alvo = $('padrao');
    if (alvo) alvo.innerHTML = '<span class="muted">Enviando…</span>';
    try {
      await pedir('enviar', { chatId: chatAtual.id, texto });
      setTimeout(varrer, 800); // arquiva a mensagem que acabou de sair
    } catch (e) {
      log('enviar falhou', e);
    } finally {
      renderMensagensPadrao();
    }
  }

  function turmaNomePorId(id) {
    const t = (turmasCache || []).find((x) => x.id === id);
    return t ? t.nome : null;
  }

  function turmaStatusPorId(id) {
    const t = (turmasCache || []).find((x) => x.id === id);
    return t ? t.funil_status : null;
  }

  function formatarData(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return '';
    return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
  }

  let metricasCarregandoPara = null;
  async function carregarMetricas(turmaId) {
    if (metricasCarregandoPara === turmaId) return; // já tem um fetch em andamento pra essa turma
    metricasCarregandoPara = turmaId;
    const r = await bg('wa_turma_metricas', { payload: { turma_id: turmaId } });
    metricasCarregandoPara = null;
    if (!chatAtual || !vinculoAtual || vinculoAtual.turma_id !== turmaId) return; // trocou de conversa enquanto carregava
    metricas = r && r.ok ? { ...r, __turmaId: turmaId } : null;
    render();
  }

  function metricasSecaoHtml(turmaId) {
    if (!metricas || metricas.__turmaId !== turmaId) {
      setTimeout(() => carregarMetricas(turmaId), 0); // dispara fora do render, dedupe por metricasCarregandoPara
      return '<span class="muted">Carregando…</span>';
    }
    const m = metricas;
    const partes = [];
    if (m.probabilidade != null) {
      partes.push(`
        <div class="prob">
          <span class="muted" style="flex:none">Probabilidade</span>
          <span class="barra"><i style="width:${Math.max(0, Math.min(100, m.probabilidade))}%"></i></span>
          <b>${m.probabilidade}%</b>
        </div>
      `);
    }
    const status = turmaStatusPorId(turmaId);
    if (status) partes.push(`<div class="linha2"><span>Status no funil</span><b>${status.replace(/</g, '&lt;')}</b></div>`);
    if (m.diasNaFase != null) partes.push(`<div class="linha2"><span>Dias na fase</span><b>${m.diasNaFase}</b></div>`);
    if (m.diasSemInteracao != null) partes.push(`<div class="linha2"><span>Dias sem interação</span><b>${m.diasSemInteracao}</b></div>`);
    if (m.semResposta) partes.push(`<div class="linha2 alerta"><span>⚠ Marcada como sem resposta</span></div>`);
    (m.reunioes || []).forEach((r, i) => {
      const rotulo = i === 0 ? 'Próxima reunião' : 'Depois';
      partes.push(`<div class="linha2"><span>${rotulo}${r.tipo_reuniao ? ' · ' + r.tipo_reuniao.replace(/</g, '&lt;') : ''}</span><b>${formatarData(r.inicio)}</b></div>`);
    });
    return partes.join('') || '<span class="muted">Sem dados de funil pra essa turma.</span>';
  }

  // =========================================================================
  //  INFORMAÇÕES DA TURMA (editar direto — mesmos campos do card no Funil)
  // =========================================================================
  const EMPRESAS_TURMA = ['AFF', 'AIF', 'AIF-SSA', 'AIF-V', 'AIM', 'SFF'];
  let turmaInfoData = null; // { __turmaId, ...campos }
  let turmaInfoCarregandoPara = null;

  async function carregarTurmaInfo(turmaId) {
    if (turmaInfoCarregandoPara === turmaId) return;
    turmaInfoCarregandoPara = turmaId;
    const r = await bg('wa_turma_info', { payload: { turma_id: turmaId } });
    turmaInfoCarregandoPara = null;
    if (!chatAtual || !vinculoAtual || vinculoAtual.turma_id !== turmaId) return;
    turmaInfoData = r && r.ok ? { ...r.turma, __turmaId: turmaId } : null;
    render();
  }

  function infoTurmaSecaoHtml(turmaId) {
    if (!turmaInfoData || turmaInfoData.__turmaId !== turmaId) {
      setTimeout(() => carregarTurmaInfo(turmaId), 0);
      return '<span class="muted">Carregando…</span>';
    }
    const t = turmaInfoData;
    const campo = (label, id, val, tipo) => `
      <div>
        <div class="muted" style="margin-bottom:2px">${label}</div>
        <input id="${id}" type="${tipo || 'text'}" value="${(val ?? '').toString().replace(/"/g, '&quot;')}" />
      </div>
    `;
    return `
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
        ${campo('Curso', 'infCurso', t.curso)}
        ${campo('Faculdade', 'infFaculdade', t.faculdade)}
        ${campo('Cidade', 'infCidade', t.cidade)}
        ${campo('Ano de formatura', 'infAno', t.ano_formatura)}
        ${campo('Turma', 'infTurma', t.turma)}
        <div>
          <div class="muted" style="margin-bottom:2px">Empresa</div>
          <select id="infEmpresa">${EMPRESAS_TURMA.map((e) => `<option value="${e}" ${e === t.empresa ? 'selected' : ''}>${e}</option>`).join('')}</select>
        </div>
        ${campo('Total de alunos', 'infTotalAlunos', t.total_alunos, 'number')}
        <div>
          <div class="muted" style="margin-bottom:2px">Alunos fechados</div>
          <input value="${t.alunos_fechados ?? 0}" disabled />
        </div>
      </div>
      <button class="g" id="salvarInfo" style="width:100%;margin-top:2px">Salvar informações</button>
      <span class="muted" id="infoStatus"></span>
    `;
  }

  function ligarInfoTurmaSecao(turmaId) {
    const btn = $('salvarInfo');
    if (!btn) return;
    btn.onclick = async () => {
      const status = $('infoStatus');
      btn.disabled = true;
      status.textContent = 'Salvando…';
      try {
        const r = await bg('wa_atualizar_turma_info', {
          payload: {
            turma_id: turmaId,
            curso: $('infCurso').value.trim(),
            faculdade: $('infFaculdade').value.trim(),
            cidade: $('infCidade').value.trim(),
            ano_formatura: $('infAno').value.trim(),
            turma: $('infTurma').value.trim(),
            empresa: $('infEmpresa').value,
            total_alunos: $('infTotalAlunos').value ? Number($('infTotalAlunos').value) : null,
          },
        });
        btn.disabled = false;
        if (r && r.ok) {
          status.style.color = '#34d399';
          status.textContent = '✓ Salvo';
          turmaInfoData = null;
          metricas = null; // nome/turmasCache podem ter mudado
          turmasCache = null;
          setTimeout(() => { if ($('infoStatus')) $('infoStatus').textContent = ''; }, 2000);
        } else {
          status.style.color = '#f87171';
          status.textContent = 'Erro: ' + ((r && r.erro) || (r && r.error) || 'tentar de novo');
        }
      } catch (e) {
        btn.disabled = false;
        status.style.color = '#f87171';
        status.textContent = 'Erro inesperado: ' + e;
      }
    };
  }

  // =========================================================================
  //  CONTATOS DA TURMA (ver, adicionar, remover)
  // =========================================================================
  let pessoasData = null; // { __turmaId, lista: [...] }
  let pessoasCarregandoPara = null;

  async function carregarPessoas(turmaId) {
    if (pessoasCarregandoPara === turmaId) return;
    pessoasCarregandoPara = turmaId;
    const r = await bg('wa_turma_pessoas', { payload: { turma_id: turmaId } });
    pessoasCarregandoPara = null;
    if (!chatAtual || !vinculoAtual || vinculoAtual.turma_id !== turmaId) return;
    pessoasData = { __turmaId: turmaId, lista: (r && r.pessoas) || [] };
    render();
  }

  function pessoasSecaoHtml(turmaId) {
    if (!pessoasData || pessoasData.__turmaId !== turmaId) {
      setTimeout(() => carregarPessoas(turmaId), 0);
      return '<span class="muted">Carregando…</span>';
    }
    const lista = pessoasData.lista;
    let html = lista.length
      ? `<div class="lista" style="max-height:140px" id="pessoasLista">` + lista.map((p) => `
          <div class="item2" style="display:flex;align-items:center;gap:6px;cursor:default">
            <div style="flex:1;min-width:0">
              <div class="t">${(p.nome || 'Sem nome').replace(/</g, '&lt;')}</div>
              ${p.telefone ? `<div class="p">${p.telefone}</div>` : ''}
            </div>
            <span class="muted" data-del="${p.id}" style="cursor:pointer;color:#f87171">remover</span>
          </div>
        `).join('') + `</div>`
      : '<span class="muted">Nenhum contato cadastrado ainda.</span>';
    html += `
      <div class="row" style="margin-top:6px">
        <input id="novoContatoNome" placeholder="Nome" style="flex:1" />
        <input id="novoContatoTel" placeholder="Telefone" style="flex:1" />
      </div>
      <button class="g" id="addContato" style="width:100%">+ Adicionar contato</button>
    `;
    return html;
  }

  function ligarPessoasSecao(turmaId) {
    const lista = $('pessoasLista');
    if (lista) {
      lista.querySelectorAll('[data-del]').forEach((el) => {
        el.onclick = async () => {
          await bg('wa_apagar_pessoa', { payload: { contato_id: el.getAttribute('data-del') } });
          pessoasData = null;
          render();
        };
      });
    }
    const add = $('addContato');
    if (add) {
      add.onclick = async () => {
        const nome = $('novoContatoNome').value.trim();
        const telefone = $('novoContatoTel').value.trim();
        if (!nome) return;
        add.disabled = true;
        await bg('wa_criar_contato', { payload: { turma_id: turmaId, nome, telefone } });
        add.disabled = false;
        pessoasData = null;
        render();
      };
    }
  }

  // =========================================================================
  //  PACOTES DA TURMA (fotografia — ver, criar a partir de template, editar)
  // =========================================================================
  let pacotesData = null; // { __turmaId, lista: [...] }
  let pacotesCarregandoPara = null;
  let catalogoData = null; // { itens, templates } — global, não muda por turma
  let catalogoCarregando = false;
  let formPacote = null; // null = fechado; { id, nome, valor, parcelas, itensSelecionados: Set }

  async function carregarPacotes(turmaId) {
    if (pacotesCarregandoPara === turmaId) return;
    pacotesCarregandoPara = turmaId;
    const r = await bg('wa_turma_pacotes', { payload: { turma_id: turmaId } });
    pacotesCarregandoPara = null;
    if (!chatAtual || !vinculoAtual || vinculoAtual.turma_id !== turmaId) return;
    pacotesData = { __turmaId: turmaId, lista: (r && r.pacotes) || [] };
    render();
  }

  async function getCatalogoPacotes() {
    if (catalogoData) return catalogoData;
    if (!catalogoCarregando) {
      catalogoCarregando = true;
      const r = await bg('wa_catalogo_pacotes');
      catalogoCarregando = false;
      catalogoData = { itens: (r && r.itens) || [], templates: (r && r.templates) || [] };
    }
    return catalogoData || { itens: [], templates: [] };
  }

  function formatBRL(v) {
    return (Number(v) || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function pacotesSecaoHtml(turmaId) {
    if (!pacotesData || pacotesData.__turmaId !== turmaId) {
      setTimeout(() => carregarPacotes(turmaId), 0);
      return '<span class="muted">Carregando…</span>';
    }
    const lista = pacotesData.lista;
    let html = lista.length
      ? lista.map((p) => `
          <div class="stageCard">
            <div class="stageTop">
              <b>${(p.nome || '').replace(/</g, '&lt;')}</b>
              <span class="contagem">R$ ${formatBRL(p.valor)} · ${p.parcelas}x</span>
            </div>
            <div class="muted">${(p.itens || []).length} ite${(p.itens || []).length === 1 ? 'm' : 'ns'}</div>
            <div class="row" style="margin-top:6px">
              <button class="g" data-editar="${p.id}" style="flex:1">Editar</button>
              <button class="g" data-remover="${p.id}" style="flex:1;color:#f87171">Remover</button>
            </div>
          </div>
        `).join('')
      : '<span class="muted">Nenhum pacote cadastrado ainda.</span>';
    html += formPacote ? pacoteFormHtml() : `<button class="g" id="novoPacote" style="width:100%;margin-top:4px">+ Novo pacote</button>`;
    return html;
  }

  function pacoteFormHtml() {
    const cat = catalogoData || { itens: [], templates: [] };
    const f = formPacote;
    return `
      <div class="stageCard atual" id="formPacoteBox" style="margin-top:6px">
        ${cat.templates.length ? `
          <select id="pkTemplate" style="margin-bottom:6px">
            <option value="">Começar do zero…</option>
            ${cat.templates.map((t) => `<option value="${t.id}">${t.nome.replace(/</g, '&lt;')}</option>`).join('')}
          </select>
        ` : ''}
        <input id="pkNome" placeholder="Nome do pacote (ex: Luxo)" value="${(f.nome || '').replace(/"/g, '&quot;')}" style="margin-bottom:6px" />
        <div class="row" style="margin-bottom:6px">
          <input id="pkValor" type="number" step="0.01" placeholder="Valor" value="${f.valor || ''}" style="flex:1" />
          <input id="pkParcelas" type="number" placeholder="Parcelas" value="${f.parcelas || 1}" style="flex:1" />
        </div>
        ${cat.itens.length ? `
          <div class="muted" style="margin-bottom:2px">Itens do pacote</div>
          <div class="lista" style="max-height:140px" id="pkItens">
            ${cat.itens.map((it) => `
              <label class="itemCk">
                <input type="checkbox" data-cat="${it.id}" ${f.itensSelecionados.has(it.nome) ? 'checked' : ''} />
                <span>${it.nome.replace(/</g, '&lt;')}</span>
              </label>
            `).join('')}
          </div>
        ` : ''}
        <div class="row" style="margin-top:6px">
          <button class="g" id="pkCancelar" style="flex:1">Cancelar</button>
          <button class="pill pill-orange" id="pkSalvar" style="flex:1">${f.id ? 'Salvar' : 'Criar pacote'}</button>
        </div>
        <span class="muted" id="pkStatus"></span>
      </div>
    `;
  }

  function ligarPacotesSecao(turmaId) {
    root.querySelectorAll('[data-editar]').forEach((btn) => {
      btn.onclick = async () => {
        const id = btn.getAttribute('data-editar');
        const p = pacotesData.lista.find((x) => x.id === id);
        if (!p) return;
        await getCatalogoPacotes();
        formPacote = { id, nome: p.nome, valor: p.valor, parcelas: p.parcelas, itensSelecionados: new Set(p.itens || []) };
        render();
      };
    });
    root.querySelectorAll('[data-remover]').forEach((btn) => {
      btn.onclick = async () => {
        if (!confirm('Remover esse pacote?')) return;
        await bg('wa_pacote_remover', { payload: { id: btn.getAttribute('data-remover') } });
        pacotesData = null;
        render();
      };
    });
    const novo = $('novoPacote');
    if (novo) {
      novo.onclick = async () => {
        await getCatalogoPacotes();
        formPacote = { id: null, nome: '', valor: '', parcelas: 1, itensSelecionados: new Set() };
        render();
      };
    }
    const cancelar = $('pkCancelar');
    if (cancelar) cancelar.onclick = () => { formPacote = null; render(); };
    const tplSel = $('pkTemplate');
    if (tplSel) {
      tplSel.onchange = () => {
        const t = (catalogoData.templates || []).find((x) => x.id === tplSel.value);
        if (t) {
          formPacote.nome = t.nome;
          formPacote.itensSelecionados = new Set(t.itens || []);
        }
        render();
      };
    }
    const itensBox = $('pkItens');
    if (itensBox) {
      itensBox.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
        cb.onchange = () => {
          const item = catalogoData.itens.find((it) => it.id === cb.getAttribute('data-cat'));
          if (!item) return;
          if (cb.checked) formPacote.itensSelecionados.add(item.nome);
          else formPacote.itensSelecionados.delete(item.nome);
        };
      });
    }
    const salvar = $('pkSalvar');
    if (salvar) {
      salvar.onclick = async () => {
        const status = $('pkStatus');
        const nome = $('pkNome').value.trim();
        if (!nome) { status.style.color = '#fbbf24'; status.textContent = '⚠ Dê um nome ao pacote.'; return; }
        formPacote.valor = $('pkValor').value;
        formPacote.parcelas = $('pkParcelas').value;
        salvar.disabled = true;
        status.textContent = 'Salvando…';
        const payload = {
          turma_id: turmaId,
          nome,
          valor: formPacote.valor,
          parcelas: formPacote.parcelas,
          itens: Array.from(formPacote.itensSelecionados),
        };
        const r = formPacote.id
          ? await bg('wa_pacote_atualizar', { payload: { id: formPacote.id, ...payload } })
          : await bg('wa_pacote_adicionar', { payload });
        salvar.disabled = false;
        if (r && r.ok) {
          formPacote = null;
          pacotesData = null;
          render();
        } else {
          status.style.color = '#f87171';
          status.textContent = 'Erro: ' + ((r && r.erro) || (r && r.error) || 'tentar de novo');
        }
      };
    }
  }

  // =========================================================================
  //  ETAPA DO FUNIL + CHECKLIST (ver e mudar, sem sair do WhatsApp Web)
  // =========================================================================
  const STAGE_KEYS = ['stage-1', 'stage-2', 'stage-3', 'stage-4', 'stage-5'];
  const STAGE_NOMES = {
    'stage-1': 'Prospecção', 'stage-2': 'Qualificação/Contato', 'stage-3': 'Reunião Comissão',
    'stage-4': 'Reunião Turma', 'stage-5': 'Decisão', 'stage-6': 'Fechou ou Perdeu',
  };
  let checklistData = null; // { __turmaId, stage, stageNome, itens, checklist }
  let checklistCarregandoPara = null;
  let motivosPerdaCache = null;

  async function getMotivosPerda() {
    if (motivosPerdaCache) return motivosPerdaCache;
    const r = await bg('wa_motivos_perda');
    motivosPerdaCache = (r && r.motivos) || [];
    return motivosPerdaCache;
  }

  async function carregarChecklist(turmaId) {
    if (checklistCarregandoPara === turmaId) return;
    checklistCarregandoPara = turmaId;
    const r = await bg('wa_turma_checklist', { payload: { turma_id: turmaId } });
    checklistCarregandoPara = null;
    if (!chatAtual || !vinculoAtual || vinculoAtual.turma_id !== turmaId) return;
    checklistData = r && r.ok ? { ...r, __turmaId: turmaId } : null;
    render();
  }

  function etapaSecaoHtml(turmaId) {
    if (!checklistData || checklistData.__turmaId !== turmaId) {
      setTimeout(() => carregarChecklist(turmaId), 0);
      return '<span class="muted">Carregando…</span>';
    }
    const c = checklistData;
    if (!c.stage) return '<span class="muted">Essa turma não tem um card no Funil ainda.</span>';
    if (c.stage === 'stage-6') {
      return `
        <div class="stageCard atual">
          <div class="stageTop"><b>Fechou ou Perdeu</b><span class="badge">ATUAL</span></div>
        </div>
        <button class="g" id="reabrirEtapa" style="width:100%">Reabrir (voltar pra Decisão)</button>
      `;
    }
    let html = `<div class="lista" id="stagesLista" style="max-height:320px">`;
    html += (c.stages || []).map((st) => `
      <div class="stageCard ${st.atual ? 'atual' : ''}">
        <div class="stageTop">
          <b>${st.nome}</b>
          ${st.atual ? '<span class="badge">ATUAL</span>' : ''}
          <span class="contagem">${st.concluidos}/${st.total}</span>
        </div>
        ${st.itens.map((it) => `
          <label class="itemCk">
            <input type="checkbox" data-item="${it.id}" ${it.checked ? 'checked' : ''} />
            <span>${it.label.replace(/</g, '&lt;')}</span>
          </label>
        `).join('')}
      </div>
    `).join('');
    html += `</div>`;
    html += `<div class="row">
      <button class="pill pill-orange" id="btnGanhou" style="flex:1">🏆 Ganhou</button>
      <button class="pill pill-red" id="btnPerdeu" style="flex:1">❌ Perdeu</button>
    </div>`;
    html += `<details style="margin-top:2px">
      <summary class="muted" style="cursor:pointer">Mudar etapa manualmente</summary>
      <select id="selStage" style="margin-top:4px">${STAGE_KEYS.map((k) => `<option value="${k}" ${k === c.stage ? 'selected' : ''}>${STAGE_NOMES[k]}</option>`).join('')}</select>
    </details>`;
    return html;
  }

  function ligarEtapaSecao(turmaId) {
    const sel = $('selStage');
    if (sel) sel.onchange = async () => { await mudarEtapa(turmaId, sel.value); };
    const lista = $('stagesLista');
    if (lista) {
      lista.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
        cb.onchange = async () => { await toggleChecklistItem(turmaId, cb.getAttribute('data-item'), cb.checked); };
      });
    }
    const reabrir = $('reabrirEtapa');
    if (reabrir) reabrir.onclick = () => mudarEtapa(turmaId, 'stage-5');
    const btnGanhou = $('btnGanhou');
    if (btnGanhou) btnGanhou.onclick = () => marcarResultado(turmaId, 'ganho');
    const btnPerdeu = $('btnPerdeu');
    if (btnPerdeu) {
      btnPerdeu.onclick = async () => {
        const motivos = await getMotivosPerda();
        const wrap = document.createElement('div');
        wrap.style.cssText = 'display:flex;flex-direction:column;gap:4px;flex:1';
        wrap.innerHTML = `
          <select id="selMotivoPerda"><option value="">Motivo da perda…</option>${motivos.map((m) => `<option value="${m.replace(/"/g, '&quot;')}">${m.replace(/</g, '&lt;')}</option>`).join('')}</select>
          <button class="b" id="confirmarPerdeu" style="width:100%">Confirmar</button>
        `;
        btnPerdeu.replaceWith(wrap);
        $('confirmarPerdeu').onclick = () => marcarResultado(turmaId, 'perdido', $('selMotivoPerda').value);
      };
    }
  }

  async function mudarEtapa(turmaId, novoStage) {
    checklistData = null;
    metricas = null;
    render();
    await bg('wa_mudar_etapa', { payload: { turma_id: turmaId, stage: novoStage } });
    carregarChecklist(turmaId);
    carregarMetricas(turmaId);
  }

  async function toggleChecklistItem(turmaId, itemId, checked) {
    const r = await bg('wa_checklist_toggle', { payload: { turma_id: turmaId, item_id: itemId, checked } });
    checklistData = null;
    metricas = null;
    render();
    if (r && r.avancou) log('checklist completo — avançou de etapa sozinho');
  }

  async function marcarResultado(turmaId, outcome, lostReason) {
    await bg('wa_marcar_resultado', { payload: { turma_id: turmaId, outcome, lost_reason: lostReason || null } });
    checklistData = null;
    metricas = null;
    render();
  }

  // =========================================================================
  //  AGENDAR REUNIÃO (usa a mesma função que já sincroniza com o Google Agenda)
  // =========================================================================
  function agendarSecaoHtml() {
    return `
      <select id="agModalidade">
        <option value="ON">Online</option>
        <option value="PR-S">Presencial no estúdio</option>
        <option value="PR-F">Presencial fora do estúdio</option>
      </select>
      <input id="agTipo" placeholder="Tipo (ex: Comissão, Turma)" />
      <input id="agQuando" type="datetime-local" />
      <button class="pill pill-orange" id="agEnviar">📅 Agendar reunião</button>
      <span id="agStatus" style="font-size:11px;color:#94a3b8"></span>
    `;
  }

  function ligarAgendarSecao(turmaId) {
    const btn = $('agEnviar');
    if (!btn) return;
    btn.onclick = async () => {
      const status = $('agStatus');
      try {
        const modalidade = $('agModalidade').value;
        const tipo = $('agTipo').value.trim() || 'Turma';
        const quando = $('agQuando').value; // "YYYY-MM-DDTHH:mm" local
        if (!quando) { status.style.color = '#fbbf24'; status.textContent = '⚠ Escolha data e hora antes de agendar.'; return; }
        const inicio = new Date(quando);
        if (isNaN(inicio.getTime())) { status.style.color = '#fbbf24'; status.textContent = '⚠ Data/hora inválida.'; return; }
        const fim = new Date(inicio.getTime() + 60 * 60000);
        btn.disabled = true;
        status.style.color = '#94a3b8';
        status.textContent = 'Agendando…';
        const r = await bg('wa_agendar_reuniao', {
          payload: { turma_id: turmaId, tipo_reuniao: tipo, modalidade, inicio: inicio.toISOString(), fim: fim.toISOString() },
        });
        btn.disabled = false;
        if (r && r.ok) {
          status.style.color = '#34d399';
          status.textContent = '✓ Agendada e sincronizada com o Google Agenda';
          $('agTipo').value = '';
          $('agQuando').value = '';
          metricas = null;
          render();
        } else {
          status.style.color = '#f87171';
          status.textContent = 'Erro: ' + ((r && r.erro) || (r && r.error) || 'tentar de novo');
          log('agendar reunião falhou', r);
        }
      } catch (e) {
        btn.disabled = false;
        status.style.color = '#f87171';
        status.textContent = 'Erro inesperado: ' + e;
        log('agendar reunião — exceção', e);
      }
    };
  }

  async function verConversa() {
    if (!chatAtual) return;
    modoConversa = true;
    mensagensConversa = null;
    render();
    const idAlvo = chatAtual.id;
    const r = await bg('wa_chat_mensagens', { payload: { chat_wa_id: idAlvo, limite: 40 } });
    if (!chatAtual || chatAtual.id !== idAlvo) return;
    mensagensConversa = (r && r.mensagens) || [];
    render();
  }

  async function criarContato(turmaId) {
    if (!chatAtual || chatAtual.isGroup || !turmaId) return;
    $('body').innerHTML = '<span class="muted">Criando contato…</span>';
    const r = await bg('wa_criar_contato', {
      payload: { nome: chatAtual.nome, telefone: chatAtual.telefone, chat_wa_id: chatAtual.id, turma_id: turmaId },
    });
    modoSeletor = false;
    if (r && r.ok) {
      vinculoAtual = { turma_id: r.turma_id, contato_id: r.contato_id, origem: 'dm', vinculo: 'contato' };
      render();
      setTimeout(varrer, 500);
    } else {
      log('criar_contato erro', r && r.erro);
      atualizarChat();
    }
  }

  async function vincular(turmaId, ignorar) {
    if (!chatAtual) return;
    const payload = chatAtual.isGroup
      ? { tipo: 'grupo', grupo_wa_id: chatAtual.id, grupo_nome: chatAtual.nome, turma_id: turmaId, ignorar: !!ignorar }
      : { tipo: 'dm', telefone: chatAtual.telefone, chat_wa_id: chatAtual.id, nome: chatAtual.nome, turma_id: turmaId, ignorar: !!ignorar };
    $('body').innerHTML = '<span class="muted">Salvando…</span>';
    const r = await bg('wa_vincular', { payload });
    modoSeletor = false;
    if (r && r.ok) {
      vinculoAtual = ignorar
        ? { ignorar: true }
        : { turma_id: turmaId, origem: chatAtual.isGroup ? 'grupo' : 'dm' };
      render();
      if (turmaId) setTimeout(varrer, 500); // já arquiva o histórico recente
    } else {
      vinculoAtual = null;
      render();
      log('vincular erro', r && r.erro);
    }
  }

  // resolve a conversa aberta e atualiza o widget
  async function atualizarChat() {
    try {
      const ativo = await pedir('ativo').catch(() => null);
      const novoChat = ativo && ativo.id ? ativo : null;
      if (!novoChat || !chatAtual || novoChat.id !== chatAtual.id) {
        modoSeletor = false;
        modoConversa = false;
        infoChat = null;
        metricas = null;
        checklistData = null;
        turmaInfoData = null;
        pessoasData = null;
        pacotesData = null;
        formPacote = null;
      }
      chatAtual = novoChat;
      if (!chatAtual) { render(); return; }
      const resolver = chatAtual.isGroup
        ? { grupo_wa_id: chatAtual.id, grupo_nome: chatAtual.nome }
        : { telefone: chatAtual.telefone };
      const r = await bg('resolver', { payload: resolver });
      vinculoAtual = r && !r.erro ? r : null;
      if (vinculoAtual && vinculoAtual.turma_id) getTurmas(); // pré-carrega nomes
      render();
      atualizarInfoChat(chatAtual.id);
      // Aluno da planilha de Adesões > Turmas Fechadas: se o telefone dessa DM
      // bate com um aluno "pendente" da turma vinculada, marca sozinho como
      // "mandei mensagem" (não sobrescreve quem já foi marcado à mão).
      if (vinculoAtual && vinculoAtual.turma_id && !chatAtual.isGroup && chatAtual.telefone) {
        bg('wa_planilha_vincular', {
          payload: { turma_id: vinculoAtual.turma_id, telefone: chatAtual.telefone, chat_wa_id: chatAtual.id },
        }).catch(() => {});
      }
    } catch (e) {
      log('atualizarChat', e);
    }
  }

  function atualizarInfoChat(idAlvo) {
    bg('wa_chat_info', { payload: { chat_wa_id: idAlvo } }).then((info) => {
      if (chatAtual && chatAtual.id === idAlvo && info && info.ok) { infoChat = info; render(); }
    });
  }

  // =========================================================================
  //  VARREDURA
  // =========================================================================
  let varrendo = false;
  let sincronizandoChatId = null; // chat_wa_id que está baixando/salvando mensagens agora (pro indicador no painel)
  async function varrer() {
    if (varrendo) return;
    varrendo = true;
    try {
      try {
        const st = await pedir('status');
        const e0 = await getEstado();
        e0.waPronto = !!(st && st.pronto);
        e0.waAutenticado = !!(st && st.autenticado);
        e0.waVistoEm = new Date().toISOString();
        await setEstado(e0);
      } catch (_) {}

      const cfg = await bg('config', {});
      if (!cfg || !cfg.temSessao) return;
      if (cfg.autoSync === false) return;

      const ativo = chatAtual || (await pedir('ativo').catch(() => null));
      if (!ativo || !ativo.id) return;

      let r = vinculoAtual;
      if (!r || (chatAtual && r && r.__paraChat && r.__paraChat !== ativo.id)) {
        const resolver = ativo.isGroup
          ? { grupo_wa_id: ativo.id, grupo_nome: ativo.nome }
          : { telefone: ativo.telefone };
        r = await bg('resolver', { payload: resolver });
      }
      if (!r || r.erro || r.ignorar) return;
      if (r.vincular || !r.turma_id) return; // aguardando vínculo manual no widget

      const estado = await getEstado();
      const desde = estado.sincronizadoAte[ativo.id] || 0;
      sincronizandoChatId = ativo.id;
      if (chatAtual && chatAtual.id === ativo.id) render();
      const msgs = await pedir('mensagens', {
        chatId: ativo.id, count: CFG.MAX_MSGS_POR_SYNC, desde, comAudio: true,
      });
      if (!msgs || !msgs.length) return;

      const mensagens = msgs
        .filter((m) => m.wa_msg_id)
        .map((m) => ({
          ...m,
          turma_id: r.turma_id,
          contato_id: r.contato_id || null,
          origem: ativo.isGroup ? 'grupo' : 'dm',
          chat_wa_id: ativo.id,
          grupo_nome: ativo.isGroup ? ativo.nome : null,
        }));

      const resp = await bg('salvar', {
        payload: { acao: 'salvar', chat_wa_id: ativo.id, mensagens },
      });
      if (resp && resp.ok) {
        const maxT = msgs.reduce((mx, m) => Math.max(mx, Date.parse(m.enviada_em) || 0), desde);
        estado.sincronizadoAte[ativo.id] = maxT;
        const hoje = new Date().toISOString().slice(0, 10);
        if (estado.dia !== hoje) { estado.dia = hoje; estado.salvasHoje = 0; }
        estado.salvasHoje += resp.salvas || 0;
        estado.ultimaSync = new Date().toISOString();
        await setEstado(estado);
        if (resp.salvas) log(`+${resp.salvas} mensagens arquivadas (${ativo.nome})`);
        if (resp.salvas && chatAtual && chatAtual.id === ativo.id) {
          atualizarInfoChat(ativo.id); // contagem/última mensagem mudou, atualiza na hora
        }
      }
    } catch (e) {
      log('varrer falhou', e);
    } finally {
      varrendo = false;
      const eraOChatAberto = chatAtual && chatAtual.id === sincronizandoChatId;
      sincronizandoChatId = null;
      if (eraOChatAberto) render();
    }
  }

  // ---- bootstrap ----
  (async () => {
    await injetar('vendor/wppconnect-wa.js');
    await injetar('wa-inject.js');
    const montar = () => {
      if (!document.body) return setTimeout(montar, 500);
      document.body.appendChild(host);
      document.documentElement.classList.add('amorin-painel-aberto'); // painel já começa aberto
      render();
      atualizarChat();
    };
    montar();
    setInterval(varrer, CFG.INTERVALO_SYNC_MS);
    setInterval(atualizarChat, 20000);
    setTimeout(varrer, 15000);
  })();

  chrome.runtime.onMessage.addListener((msg, _s, sendResponse) => {
    if (msg && msg.cmd === 'varrer_agora') { varrer().then(() => sendResponse({ ok: true })); return true; }
  });
})();
